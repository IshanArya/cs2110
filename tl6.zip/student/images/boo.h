/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 boo boo.png 
 * Time-stamp: Monday 04/08/2019, 14:07:53
 * 
 * Image Information
 * -----------------
 * boo.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOO_H
#define BOO_H

extern const unsigned short boo[225];
#define BOO_SIZE 450
#define BOO_LENGTH 225
#define BOO_WIDTH 15
#define BOO_HEIGHT 15
#define BOO_TRANSPARENT 0x6c1f

#endif

