/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 bear bear.png 
 * Time-stamp: Wednesday 04/10/2019, 00:20:30
 * 
 * Image Information
 * -----------------
 * bear.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEAR_H
#define BEAR_H

extern const unsigned short bear[38400];
#define BEAR_SIZE 76800
#define BEAR_LENGTH 38400
#define BEAR_WIDTH 240
#define BEAR_HEIGHT 160

#endif

