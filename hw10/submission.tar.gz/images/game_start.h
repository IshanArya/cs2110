/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 game_start game_start.png 
 * Time-stamp: Wednesday 04/10/2019, 00:51:28
 * 
 * Image Information
 * -----------------
 * game_start.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME_START_H
#define GAME_START_H

extern const unsigned short game_start[38400];
#define GAME_START_SIZE 76800
#define GAME_START_LENGTH 38400
#define GAME_START_WIDTH 240
#define GAME_START_HEIGHT 160

#endif

