/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 game game.png 
 * Time-stamp: Thursday 04/11/2019, 09:12:50
 * 
 * Image Information
 * -----------------
 * game.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME_H
#define GAME_H

extern const unsigned short game[38400];
#define GAME_SIZE 76800
#define GAME_LENGTH 38400
#define GAME_WIDTH 240
#define GAME_HEIGHT 160

#endif

