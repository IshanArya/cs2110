/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 game_end game_end.png 
 * Time-stamp: Thursday 04/11/2019, 09:41:04
 * 
 * Image Information
 * -----------------
 * game_end.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME_END_H
#define GAME_END_H

extern const unsigned short game_end[38400];
#define GAME_END_SIZE 76800
#define GAME_END_LENGTH 38400
#define GAME_END_WIDTH 240
#define GAME_END_HEIGHT 160

#endif

