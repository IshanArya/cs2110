#!/bin/bash
set -e
rm -f hw10.zip
zip -r hw10.zip * -x pkg.sh
