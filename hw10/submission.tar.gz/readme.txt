Hi! Thanks for playing my game.
Basically avoid the bouncing red ball by moving the character with the arrow keys. You have 9 lives.

Good luck!