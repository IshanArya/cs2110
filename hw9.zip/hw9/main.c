#include "list.h"
#include "dog.h"

#include <stdio.h>

int main() {
    printf("Test");
}