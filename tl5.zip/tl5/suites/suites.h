extern Suite *list_suite(void);
extern Suite *hash_table_suite(void);
