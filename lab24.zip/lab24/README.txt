======================================================================
CS2110                        Lab 24                       Spring 2019
======================================================================

Oh no! Our image of a panda has gotten all scrambled up! Implement two 
functions in main.c and modify four function calls to fix it. Show us 
the correctly drawn panda when you're done.

Read the instructions in the main.c file

For this lab, cd into the directory containing main.c
and the Makefile. To build and run the emulator, run:

    $ make emu

