#include "lib.h"
#include "panda_tl.h"
#include "panda_tr.h"
#include "panda_br.h"
#include "panda_bl.h"

void drawImageFlippedUD(int row, int col, int width, int height, const u16 *image) {
    // TODO: Implement this function that draws the image, but flipped upside-down. You MUST use DMA!

    UNUSED_PARAM(row);
    UNUSED_PARAM(col);
    UNUSED_PARAM(width);
    UNUSED_PARAM(height);
    UNUSED_PARAM(image);
}

void drawImageFlippedLR(int row, int col, int width, int height, const u16 *image) {
    // TODO: Implement this function that draws the image, but flipped left-right. You MUST use DMA!

    UNUSED_PARAM(row);
    UNUSED_PARAM(col);
    UNUSED_PARAM(width);
    UNUSED_PARAM(height);
    UNUSED_PARAM(image);
}

void drawImage(int row, int col, int width, int height, const u16 *image) {
    for (int r = row; r < row + height; r++) {
        DMA[3].src = image + OFFSET(r - row, 0, width);
        DMA[3].dst = videoBuffer + OFFSET(r, col, WIDTH);
        DMA[3].cnt = width | DMA_ON;
    }
}


int main(void) {
    REG_DISPCNT = MODE3 | BG2_ENABLE;

    // TODO:
    // Oh no! The panda isn't being drawn correctly.
    // Change these first two to call your drawImageFlippedUD function
    // And the last two to call your drawImageFlippedLR function
    drawImage(0, 0, 120, 80, panda_tl);
    drawImage(0, 120, 120, 80, panda_tr);

    drawImage(80, 0, 120, 80, panda_bl);
    drawImage(80, 120, 120, 80, panda_br);

    while(1) {

    }
}
