/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 panda_tr panda_tr.jpg 
 * Time-stamp: Tuesday 04/09/2019, 19:53:25
 * 
 * Image Information
 * -----------------
 * panda_tr.jpg 120@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PANDA_TR_H
#define PANDA_TR_H

extern const unsigned short panda_tr[9600];
#define PANDA_TR_SIZE 19200
#define PANDA_TR_LENGTH 9600
#define PANDA_TR_WIDTH 120
#define PANDA_TR_HEIGHT 80

#endif

