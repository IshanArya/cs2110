/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 panda_bl panda_bl.jpg 
 * Time-stamp: Tuesday 04/09/2019, 19:53:32
 * 
 * Image Information
 * -----------------
 * panda_bl.jpg 120@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PANDA_BL_H
#define PANDA_BL_H

extern const unsigned short panda_bl[9600];
#define PANDA_BL_SIZE 19200
#define PANDA_BL_LENGTH 9600
#define PANDA_BL_WIDTH 120
#define PANDA_BL_HEIGHT 80

#endif

