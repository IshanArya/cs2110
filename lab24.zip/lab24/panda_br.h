/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 panda_br panda_br.jpg 
 * Time-stamp: Tuesday 04/09/2019, 19:53:28
 * 
 * Image Information
 * -----------------
 * panda_br.jpg 120@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PANDA_BR_H
#define PANDA_BR_H

extern const unsigned short panda_br[9600];
#define PANDA_BR_SIZE 19200
#define PANDA_BR_LENGTH 9600
#define PANDA_BR_WIDTH 120
#define PANDA_BR_HEIGHT 80

#endif

