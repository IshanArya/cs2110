/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 panda_tl panda_tl.jpg 
 * Time-stamp: Tuesday 04/09/2019, 19:52:00
 * 
 * Image Information
 * -----------------
 * panda_tl.jpg 120@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PANDA_TL_H
#define PANDA_TL_H

extern const unsigned short panda_tl[9600];
#define PANDA_TL_SIZE 19200
#define PANDA_TL_LENGTH 9600
#define PANDA_TL_WIDTH 120
#define PANDA_TL_HEIGHT 80

#endif

